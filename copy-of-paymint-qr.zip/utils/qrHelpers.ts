
import { PaymentDetails, ContactDetails, AppDetails, WifiDetails, SocialDetails } from '../types';

export const generateUPIString = (details: PaymentDetails): string => {
  const { upiId, name, amount, currency } = details;
  if (!upiId) return '';
  
  const params = new URLSearchParams();
  params.append('pa', upiId);
  if (name) params.append('pn', name);
  if (amount) params.append('am', amount);
  params.append('cu', currency || 'INR');

  return `upi://pay?${params.toString()}`;
};

export const generateVCard = (details: ContactDetails): string => {
  return `BEGIN:VCARD
VERSION:3.0
N:${details.lastName};${details.firstName};;;
FN:${details.firstName} ${details.lastName}
ORG:${details.organization}
TITLE:${details.title}
TEL;TYPE=CELL:${details.phone}
EMAIL:${details.email}
END:VCARD`;
};

export const generateWifiString = (details: WifiDetails): string => {
  const { ssid, password, encryption } = details;
  if (!ssid) return '';
  return `WIFI:T:${encryption};S:${ssid};P:${password};;`;
};

export const generateAppStoreString = (details: AppDetails): string => {
  return details.androidUrl || details.iosUrl || '';
};

export const generateWhatsappString = (details: SocialDetails): string => {
  if (!details.phone) return '';
  const text = details.message ? `&text=${encodeURIComponent(details.message)}` : '';
  return `https://wa.me/${details.phone.replace(/\+/g, '')}${text}`;
};

export const generateInstagramString = (details: SocialDetails): string => {
  if (!details.username) return '';
  return `https://instagram.com/${details.username.replace('@', '')}`;
};

export const generateFacebookString = (details: SocialDetails): string => {
  if (!details.username) return '';
  return `https://facebook.com/${details.username}`;
};
