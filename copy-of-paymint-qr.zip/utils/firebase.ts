
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDx6TfNOrohEY8mVZhrNWp388D3DIkYHAs",
  authDomain: "paymint-qr.firebaseapp.com",
  projectId: "paymint-qr",
  storageBucket: "paymint-qr.firebasestorage.app",
  messagingSenderId: "623529170024",
  appId: "1:623529170024:web:c19425815865c6cca957dd"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
