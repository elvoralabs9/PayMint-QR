import { PaymentDetails } from '../types';

export const generateUPIString = (details: PaymentDetails): string => {
  const { upiId, name, amount } = details;
  
  if (!upiId) return '';

  const params = new URLSearchParams();
  params.append('pa', upiId);
  if (name) params.append('pn', name);
  if (amount) params.append('am', amount);
  params.append('cu', 'INR'); // Currency defaults to INR for UPI

  return `upi://pay?${params.toString()}`;
};

export const isValidUPI = (upi: string): boolean => {
  // Basic validation regex for VPA (Virtual Payment Address)
  const upiRegex = /^[\w.-]+@[\w.-]+$/;
  return upiRegex.test(upi);
};