
export type QRMode = 'payment' | 'url' | 'contact' | 'app' | 'text' | 'wifi' | 'whatsapp' | 'instagram' | 'facebook';

export interface QRCodeConfig {
  fgColor: string;
  bgColor: string;
  logoUrl: string | null;
  logoSize: number;
  cornerStyle: 'square' | 'rounded' | 'extra-rounded';
  borderConfig: {
    width: number;
    color: string;
    style: 'none' | 'solid' | 'dashed' | 'dotted' | 'double';
  };
}

export interface PaymentDetails {
  name: string;
  upiId: string;
  amount: string;
  currency: string;
}

export interface ContactDetails {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  organization: string;
  title: string;
}

export interface AppDetails {
  iosUrl: string;
  androidUrl: string;
}

export interface WifiDetails {
  ssid: string;
  password: string;
  encryption: 'WPA' | 'WEP' | 'nopass';
}

export interface SocialDetails {
  username: string; // For Insta/FB
  phone: string; // For Whatsapp
  message?: string; // For Whatsapp
}

export const CURRENCIES = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'SAR', symbol: '﷼', name: 'Saudi Riyal' },
  { code: 'BDT', symbol: '৳', name: 'Bangladeshi Taka' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham' },
];
