
import React from 'react';
import { Link2, FileText, Layers, Users, Wallet, Smartphone, Type, Wifi } from 'lucide-react';
import { QRMode } from '../types';

interface SidebarProps {
  activeMode: QRMode;
  setMode: (mode: QRMode) => void;
  isMobileOpen: boolean;
  closeMobileMenu: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeMode, setMode, isMobileOpen, closeMobileMenu }) => {
  const navItems: { icon: any, label: string, mode: QRMode }[] = [
    { icon: Wallet, label: 'Payment', mode: 'payment' },
    { icon: Link2, label: 'URL', mode: 'url' },
    { icon: Users, label: 'Contact', mode: 'contact' },
    { icon: Smartphone, label: 'App', mode: 'app' },
    { icon: Type, label: 'Text', mode: 'text' },
    { icon: Wifi, label: 'Wi-Fi', mode: 'wifi' },
  ];

  const handleItemClick = (mode: QRMode) => {
    setMode(mode);
    closeMobileMenu();
  };

  return (
    <>
      {/* Overlay for mobile */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={closeMobileMenu}
        />
      )}

      <aside className={`
        fixed md:static inset-y-0 left-0 z-40 w-64 md:w-20 lg:w-24 
        bg-white dark:bg-dark-900 border-r border-gray-200 dark:border-dark-700 
        transform transition-transform duration-300 ease-in-out
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
        flex flex-col items-center py-6 gap-2 h-[calc(100vh-4rem)] overflow-y-auto top-16
      `}>
        <div className="w-full px-4 md:px-0 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.mode}
              onClick={() => handleItemClick(item.mode)}
              className={`
                w-full md:w-16 md:h-16 rounded-xl flex md:flex-col items-center md:justify-center gap-3 md:gap-1 p-3 md:p-0 transition-all duration-200 group
                ${activeMode === item.mode
                  ? 'bg-paymint-50 dark:bg-dark-800 text-paymint-600 dark:text-paymint-400 border border-paymint-100 dark:border-dark-600 shadow-sm'
                  : 'text-gray-600 dark:text-gray-500 hover:bg-gray-50 dark:hover:bg-dark-800 hover:text-gray-900 dark:hover:text-gray-300'
                }
              `}
            >
              <item.icon
                size={24}
                className={`transition-transform md:group-hover:scale-110 ${
                  activeMode === item.mode ? 'text-paymint-500' : 'text-gray-400 dark:text-gray-500 md:group-hover:text-gray-600 dark:md:group-hover:text-gray-300'
                }`}
              />
              <span className="text-sm md:text-[10px] font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
