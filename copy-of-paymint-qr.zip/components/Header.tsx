
import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, Sun, Moon, ScanLine, FileText, Shield, Info, Mail, LogOut, UserPlus, Layers, BookOpen, User } from 'lucide-react';

interface HeaderProps {
  toggleMobileMenu: () => void;
  isMobileMenuOpen: boolean;
  isDarkMode: boolean;
  toggleTheme: () => void;
  user: any; // Firebase user object
  onAuthAction: () => void;
  onNavClick: (action: string) => void;
}

const Header: React.FC<HeaderProps> = ({ 
  toggleMobileMenu, 
  isMobileMenuOpen,
  isDarkMode,
  toggleTheme,
  user,
  onAuthAction,
  onNavClick
}) => {
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const menuItems = [
      { id: 'scan', label: 'Scan QR', icon: ScanLine },
      { id: 'generate', label: 'QR Generate', icon: Layers },
      { id: 'blog', label: 'Blog', icon: BookOpen },
      { id: 'features', label: 'Features', icon: FileText },
      { id: 'about', label: 'About Us', icon: Info },
      { id: 'privacy', label: 'Privacy Policy', icon: Shield },
      { id: 'terms', label: 'Terms & Services', icon: Shield },
      { id: 'contact', label: 'Contact', icon: Mail },
  ];

  const handleLogout = () => {
      onAuthAction();
      setIsProfileMenuOpen(false);
  };

  return (
    <>
    <header className="h-16 border-b border-gray-200 dark:border-dark-700 bg-white/80 dark:bg-dark-900/80 backdrop-blur-md flex items-center justify-between px-4 md:px-6 sticky top-0 z-50 transition-colors duration-300">
      <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavClick('generate')}>
        {/* Logo Icon */}
        <div className="w-9 h-9 bg-gradient-to-tr from-paymint-600 to-paymint-400 rounded-xl flex items-center justify-center shadow-lg shadow-paymint-500/20">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-white">
            <rect x="3" y="3" width="7" height="7" />
            <rect x="14" y="3" width="7" height="7" />
            <rect x="14" y="14" width="7" height="7" />
            <path d="M3 14h4" />
            <path d="M7 14v4" />
            <path d="M3 18h2" />
          </svg>
        </div>
        <h1 className="text-xl font-bold tracking-tight text-gray-900 dark:text-white">
          Pay<span className="text-paymint-500">Mint</span> QR
        </h1>
      </div>

      <div className="flex items-center gap-3">
        {/* Theme Toggle */}
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-xl text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-dark-700 transition-all hover:rotate-12"
          aria-label="Toggle Theme"
        >
          {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>

        <div className="hidden md:flex items-center gap-4">
            {user ? (
                <div className="relative" ref={dropdownRef}>
                    <button 
                        onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                        className="flex items-center gap-3 focus:outline-none group"
                    >
                        <div className="text-right hidden lg:block">
                            <p className="text-xs font-medium text-gray-900 dark:text-white">{user.displayName || 'Hello, User'}</p>
                            <p className="text-[10px] text-gray-500">Logged In</p>
                        </div>
                        <div
                            className="w-10 h-10 rounded-full bg-gray-100 dark:bg-dark-700 overflow-hidden border-2 border-transparent group-hover:border-paymint-500 flex items-center justify-center shadow-sm transition-all"
                            title="Account Menu"
                        >
                            {user.photoURL ? (
                                <img src={user.photoURL} alt="Profile" className="w-full h-full object-cover" />
                            ) : (
                                <span className="text-sm font-bold text-gray-700 dark:text-gray-300">{user.displayName ? user.displayName.charAt(0).toUpperCase() : 'U'}</span>
                            )}
                        </div>
                    </button>

                    {/* Profile Dropdown */}
                    {isProfileMenuOpen && (
                        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-dark-800 rounded-xl shadow-xl border border-gray-100 dark:border-dark-700 py-1 animate-in fade-in slide-in-from-top-2 z-50">
                            <div className="px-4 py-2 border-b border-gray-100 dark:border-dark-700 lg:hidden">
                                <p className="text-sm font-bold text-gray-900 dark:text-white">{user.displayName || 'Hello, User'}</p>
                                <p className="text-xs text-gray-500 truncate">{user.email}</p>
                            </div>
                            <button
                                onClick={handleLogout}
                                className="w-full text-left px-4 py-2.5 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2"
                            >
                                <LogOut size={16} />
                                Logout
                            </button>
                        </div>
                    )}
                </div>
            ) : (
                <button 
                    onClick={onAuthAction}
                    className="px-5 py-2 rounded-lg text-sm font-semibold shadow-lg transition-all transform hover:scale-105 bg-paymint-500 hover:bg-paymint-600 text-white shadow-paymint-500/20"
                >
                  Get Started
                </button>
            )}
        </div>

        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMobileMenu}
          className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-lg transition-colors relative md:hidden"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
    </header>

    {/* Mobile/Hamburger Menu Overlay */}
    <div className={`
        fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 md:hidden
        ${isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}
    `} onClick={toggleMobileMenu} />

    {/* Side Drawer Menu */}
    <div className={`
        fixed inset-y-0 right-0 z-50 w-72 bg-white dark:bg-dark-900 shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col
        ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}
    `}>
        <div className="p-5 border-b border-gray-200 dark:border-dark-700 flex justify-between items-center">
            <div className="flex items-center gap-2">
                {user && (
                    <div className="w-8 h-8 rounded-full bg-paymint-500 text-white flex items-center justify-center font-bold text-xs overflow-hidden">
                         {user.photoURL ? <img src={user.photoURL} alt="U" className="w-full h-full object-cover"/> : (user.displayName?.[0] || 'U')}
                    </div>
                )}
                <span className="font-bold text-lg text-gray-900 dark:text-white">{user ? (user.displayName || 'Hello, User') : 'Menu'}</span>
            </div>
            <button onClick={toggleMobileMenu} className="p-1 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-full transition-colors">
                <X size={20} className="text-gray-500" />
            </button>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
            {menuItems.map((item) => (
                <button
                    key={item.id}
                    onClick={() => { onNavClick(item.id); toggleMobileMenu(); }}
                    className="w-full flex items-center gap-3 px-4 py-3.5 text-left text-gray-700 dark:text-gray-200 hover:bg-paymint-50 dark:hover:bg-paymint-900/10 hover:text-paymint-600 dark:hover:text-paymint-400 rounded-xl transition-colors group"
                >
                    <item.icon size={18} className="text-gray-400 group-hover:text-paymint-500 transition-colors" />
                    <span className="font-medium">{item.label}</span>
                </button>
            ))}
        </div>

        <div className="p-4 border-t border-gray-200 dark:border-dark-700">
            <button 
                onClick={() => { onAuthAction(); toggleMobileMenu(); }}
                className={`
                    w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all
                    ${user 
                        ? 'bg-red-50 dark:bg-red-900/10 text-red-600 dark:text-red-400 hover:bg-red-100' 
                        : 'bg-paymint-500 text-white hover:bg-paymint-600 shadow-lg shadow-paymint-500/20'
                    }
                `}
            >
                {user ? <LogOut size={18} /> : <UserPlus size={18} />}
                {user ? 'Sign Out' : 'Sign Up / Login'}
            </button>
        </div>
    </div>
    </>
  );
};

export default Header;
