
import React, { useState } from 'react';
import { ScanLine, FileText, Shield, Info, BookOpen, CheckCircle2, ArrowRight, ChevronLeft, Calendar, User, Loader2 } from 'lucide-react';
import AdSpace from './AdSpace';

interface PageProps {
  page: string;
  onNavigate: (page: string) => void;
}

const Pages: React.FC<PageProps> = ({ page, onNavigate }) => {
  // Blog state
  const [selectedBlog, setSelectedBlog] = useState<number | null>(null);
  const [visibleBlogs, setVisibleBlogs] = useState(15);

  // Diverse Blog Data with unique topics and images
  const allBlogs = [
    {
        id: 1,
        title: "The Evolution of QR Codes in Retail 2025",
        category: "Retail",
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?auto=format&fit=crop&w=800&q=80",
        desc: "How brick-and-mortar stores are bridging the gap to digital with smart packaging and shelf-edge QR codes.",
    },
    {
        id: 2,
        title: "Why Dynamic QR Codes are Essential for Marketing",
        category: "Marketing",
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80",
        desc: "Stop reprinting materials. Learn how dynamic codes save money and provide real-time analytics for your campaigns.",
    },
    {
        id: 3,
        title: "Top 10 QR Code Design Trends for This Year",
        category: "Design",
        image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=800&q=80",
        desc: "From gradient colors to embedded logos, see what's hot in the world of scannable art.",
    },
    {
        id: 4,
        title: "Contactless Payments: The UPI Revolution",
        category: "Finance",
        image: "https://images.unsplash.com/photo-1556742208-9979d1a8ce8d?auto=format&fit=crop&w=800&q=80",
        desc: "Analyzing the massive shift towards scan-and-pay systems in developing economies and what it means for global finance.",
    },
    {
        id: 5,
        title: "QR Codes in Healthcare: Improving Patient Care",
        category: "Healthcare",
        image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80",
        desc: "How hospitals are using simple codes for patient identification, record access, and medication tracking.",
    },
    {
        id: 6,
        title: "Enhancing Restaurant Menus with Digital Tech",
        category: "Hospitality",
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80",
        desc: "The paper menu is dying. Here's how digital menus improve hygiene, speed, and average order value.",
    },
    {
        id: 7,
        title: "Cybersecurity: Are QR Codes Safe?",
        category: "Security",
        image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80",
        desc: "Understanding the risks of Quishing (QR Phishing) and how to protect your users from malicious scans.",
    },
    {
        id: 8,
        title: "The Ultimate Guide to vCard QR Codes",
        category: "Networking",
        image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80",
        desc: "Never run out of business cards again. Share your contact details instantly with a simple scan.",
    },
    {
        id: 9,
        title: "Using QR Codes for Event Ticketing",
        category: "Events",
        image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80",
        desc: "Streamline check-ins and reduce fraud with unique, encrypted QR codes for every attendee.",
    },
    {
        id: 10,
        title: "Augmented Reality and QR: A New Frontier",
        category: "Technology",
        image: "https://images.unsplash.com/photo-1633113214698-48562615935d?auto=format&fit=crop&w=800&q=80",
        desc: "Scanning a code to launch an immersive AR experience? It's closer than you think.",
    },
    {
        id: 11,
        title: "QR Codes for WiFi Sharing in Hotels",
        category: "Hospitality",
        image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=800&q=80",
        desc: "Stop asking for the password. Create a seamless guest experience with instant connection codes.",
    },
    {
        id: 12,
        title: "Measuring ROI on Print Advertising",
        category: "Analytics",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
        desc: "Print isn't dead, it's just unmeasured. Use QR codes to track exactly how many leads your flyers generate.",
    },
    {
        id: 13,
        title: "Real Estate Marketing with Virtual Tours",
        category: "Real Estate",
        image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=80",
        desc: "Put a QR code on your 'For Sale' sign and let potential buyers tour the property instantly on their phone.",
    },
    {
        id: 14,
        title: "How to Create Accessible QR Codes",
        category: "Design",
        image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=800&q=80",
        desc: "Ensuring your codes are large enough and have high contrast for users with visual impairments.",
    },
    {
        id: 15,
        title: "QR Codes in Logistics and Supply Chain",
        category: "Logistics",
        image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=800&q=80",
        desc: "Tracking packages from warehouse to doorstep with precision and ease.",
    },
    {
        id: 16,
        title: "The Psychology of Scan-to-Action",
        category: "Marketing",
        image: "https://images.unsplash.com/photo-1532619675605-1ede6c2ed2b0?auto=format&fit=crop&w=800&q=80",
        desc: "What makes a user scan? Color, placement, and call-to-action strategies that work.",
    },
    {
        id: 17,
        title: "Eco-Friendly Digital Manuals",
        category: "Sustainability",
        image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80",
        desc: "Replace thick paper instruction booklets with a single QR code linking to a PDF or video guide.",
    },
    {
        id: 18,
        title: "Donation Collection for Non-Profits",
        category: "Charity",
        image: "https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80",
        desc: "Increasing donor conversion rates by making the payment process frictionless.",
    },
    {
        id: 19,
        title: "Interactive Museum Exhibits",
        category: "Education",
        image: "https://images.unsplash.com/photo-1566127444979-b3d2a654e3d7?auto=format&fit=crop&w=800&q=80",
        desc: "Providing deeper context, audio guides, and translations for art pieces via personal devices.",
    },
    {
        id: 20,
        title: "QR Code Inventory Management",
        category: "Business",
        image: "https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=800&q=80",
        desc: "Small business inventory tracking without expensive barcode scanners.",
    },
    {
        id: 21,
        title: "Integrating QR with Social Media Contests",
        category: "Social Media",
        image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=800&q=80",
        desc: "Drive engagement and followers by linking codes directly to Instagram filters or TikTok challenges.",
    },
    {
        id: 22,
        title: "The Future of Wearable QR Technology",
        category: "Tech",
        image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80",
        desc: "T-shirts, bracelets, and temporary tattoos that link to your digital identity.",
    },
    {
        id: 23,
        title: "Smart Cities and Public Information",
        category: "Government",
        image: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?auto=format&fit=crop&w=800&q=80",
        desc: "Bus schedules, tourist maps, and emergency info available instantly on street corners.",
    },
    {
        id: 24,
        title: "Feedback Collection Made Easy",
        category: "Service",
        image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80",
        desc: "Get more customer reviews by simplifying the process to a single camera snap.",
    },
    {
        id: 25,
        title: "Authentication and Anti-Counterfeit",
        category: "Retail",
        image: "https://images.unsplash.com/photo-1617839625591-e5a789593135?auto=format&fit=crop&w=800&q=80",
        desc: "Luxury brands using encrypted QR codes to verify product authenticity.",
    },
    {
        id: 26,
        title: "The Teacher's Guide to QR in Classrooms",
        category: "Education",
        image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80",
        desc: "Sharing resources, homework assignments, and interactive quizzes with students.",
    },
    {
        id: 27,
        title: "Pet Tags: The Modern Dog Collar",
        category: "Lifestyle",
        image: "https://images.unsplash.com/photo-1583511655826-05700d52f4d9?auto=format&fit=crop&w=800&q=80",
        desc: "Storing medical info and vet contacts on your pet's collar tag.",
    },
    {
        id: 28,
        title: "Cross-Platform App Downloads",
        category: "Mobile",
        image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=800&q=80",
        desc: "Using a single QR code to route users to either the App Store or Play Store automatically.",
    },
    {
        id: 29,
        title: "Automotive Service History Tracking",
        category: "Automotive",
        image: "https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&w=800&q=80",
        desc: "Stickers on car doors that reveal maintenance logs and mechanic contact info.",
    },
    {
        id: 30,
        title: "The Minimalist Design Philosophy",
        category: "Design",
        image: "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=800&q=80",
        desc: "Why less is more when it comes to QR code customization and frame clutter.",
    }
  ];

  const renderScanPage = () => (
    <div className="max-w-md mx-auto text-center py-12 animate-in fade-in duration-500">
        <div className="w-24 h-24 bg-paymint-50 dark:bg-paymint-900/20 rounded-full flex items-center justify-center mx-auto mb-6 text-paymint-500">
            <ScanLine size={48} />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">QR Scanner</h2>
        <p className="text-gray-500 dark:text-gray-400 mb-8">
            Use your device camera to scan any QR code instantly. Supports Payment, URL, and Text QRs.
        </p>
        <div className="bg-gray-100 dark:bg-dark-800 rounded-2xl h-64 flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-dark-600 mb-6 relative overflow-hidden">
             <div className="absolute inset-0 flex items-center justify-center">
                 <p className="text-sm text-gray-400">Camera Access Required</p>
             </div>
             <div className="absolute w-48 h-48 border-2 border-paymint-500/50 rounded-lg"></div>
             <div className="absolute top-0 left-0 right-0 h-1 bg-paymint-500 shadow-[0_0_10px_#10b981] animate-[scan_2s_ease-in-out_infinite]"></div>
        </div>
        <button className="px-8 py-3 bg-paymint-500 hover:bg-paymint-600 text-white rounded-xl font-semibold shadow-lg transition-all">
            Request Camera Access
        </button>
    </div>
  );

  const renderBlogPage = () => {
      if (selectedBlog) {
          const blog = allBlogs.find(b => b.id === selectedBlog);
          return (
              <div className="max-w-7xl mx-auto py-8 animate-in fade-in slide-in-from-right-4 grid grid-cols-1 lg:grid-cols-3 gap-12">
                  <div className="lg:col-span-2">
                    <button onClick={() => setSelectedBlog(null)} className="flex items-center text-paymint-500 mb-6 hover:underline font-medium">
                        <ChevronLeft size={20} /> Back to Articles
                    </button>
                    <span className="bg-paymint-100 text-paymint-600 dark:bg-paymint-900/30 dark:text-paymint-400 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-4 inline-block">
                        {blog?.category}
                    </span>
                    <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">{blog?.title}</h1>
                    
                    {/* Blog Cover Image */}
                    <div className="mb-8 rounded-2xl overflow-hidden shadow-lg aspect-video">
                        <img src={blog?.image} alt={blog?.title} className="w-full h-full object-cover" />
                    </div>

                    <div className="flex items-center gap-6 text-sm text-gray-500 dark:text-gray-400 mb-8 border-b border-gray-200 dark:border-dark-700 pb-8">
                        <div className="flex items-center gap-2"><User size={16}/> PayMint Team</div>
                        <div className="flex items-center gap-2"><Calendar size={16}/> Feb 24, 2025</div>
                    </div>
                    
                    <div className="prose dark:prose-invert max-w-none text-gray-600 dark:text-gray-300 leading-relaxed">
                        <p className="mb-6 text-lg font-medium">{blog?.desc}</p>
                        <p className="mb-4">
                            QR codes have rapidly evolved from simple inventory tracking tools to essential components of modern marketing and user engagement strategies. In 2025, the integration of AI, augmented reality, and secure payment gateways has reshaped how businesses interact with customers.
                        </p>
                        <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-white">Why Design Matters</h3>
                        <p className="mb-4">
                            A custom QR code with a logo and brand colors can increase scan rates by up to 40%. It builds trust and recognition instantly. Gone are the days of boring black-and-white squares; today's codes are integrated into art, packaging, and even fashion.
                        </p>
                        <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-white">Data-Driven Decisions</h3>
                        <p className="mb-4">
                            Understanding who scans your code, when, and where is crucial. Our platform provides granular data to help you optimize your campaigns in real-time. Whether you are a small business owner or a marketing director, these insights are invaluable for calculating ROI.
                        </p>
                        <div className="bg-gray-100 dark:bg-dark-800 p-6 rounded-xl border-l-4 border-paymint-500 my-6 italic">
                            "The future of physical-to-digital interaction relies on seamless, secure, and beautiful access points. QR codes are that access point."
                        </div>
                        <p className="mb-4">
                            Start creating your custom QR codes today and see the difference in your customer engagement metrics.
                        </p>
                    </div>
                  </div>
                  <div className="lg:col-span-1">
                      <div className="sticky top-24 space-y-6">
                          <AdSpace type="sidebar" />
                          <div className="bg-white dark:bg-dark-800 p-6 rounded-xl border border-gray-100 dark:border-dark-700">
                              <h3 className="font-bold text-gray-900 dark:text-white mb-4">Related Topics</h3>
                              <ul className="space-y-3 text-sm text-gray-500 dark:text-gray-400">
                                  <li className="hover:text-paymint-500 cursor-pointer">Marketing Strategies</li>
                                  <li className="hover:text-paymint-500 cursor-pointer">QR Design Tips</li>
                                  <li className="hover:text-paymint-500 cursor-pointer">Analytics & Tracking</li>
                              </ul>
                          </div>
                      </div>
                  </div>
              </div>
          );
      }

      const visibleBlogList = allBlogs.slice(0, visibleBlogs);

      return (
        <div className="max-w-6xl mx-auto py-8 animate-in fade-in duration-500">
            <div className="text-center mb-16">
               <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">PayMint Insights</h2>
               <p className="text-gray-500 dark:text-gray-400 max-w-2xl mx-auto text-lg">
                   Expert guides, industry trends, and tips to master your QR code strategy.
               </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
               {visibleBlogList.map((blog) => (
                   <div key={blog.id} onClick={() => setSelectedBlog(blog.id)} className="bg-white dark:bg-dark-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-gray-100 dark:border-dark-700 group cursor-pointer flex flex-col h-full">
                       <div className="h-48 bg-gray-200 dark:bg-dark-700 relative overflow-hidden">
                           <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10"></div>
                           <img src={blog.image} alt={blog.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                           <span className="absolute bottom-4 left-4 z-20 text-white text-xs font-bold bg-paymint-500 px-2 py-1 rounded uppercase tracking-wide">{blog.category}</span>
                       </div>
                       <div className="p-6 flex flex-col flex-1">
                           <div className="text-xs text-gray-400 mb-3 flex justify-between">
                               <span>Feb 24, 2025</span>
                               <span>5 min read</span>
                           </div>
                           <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-paymint-500 transition-colors line-clamp-2">
                               {blog.title}
                           </h3>
                           <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 line-clamp-3 flex-1">
                               {blog.desc}
                           </p>
                           <div className="flex items-center text-paymint-500 font-medium text-sm mt-auto">
                               Read Article <ArrowRight size={16} className="ml-1 group-hover:translate-x-1 transition-transform" />
                           </div>
                       </div>
                   </div>
               ))}
            </div>

            {/* Load More Button */}
            {visibleBlogs < allBlogs.length && (
                <div className="text-center">
                    <button 
                        onClick={() => setVisibleBlogs(prev => Math.min(prev + 15, allBlogs.length))}
                        className="px-8 py-3 bg-white dark:bg-dark-700 border border-gray-200 dark:border-dark-600 hover:bg-gray-50 dark:hover:bg-dark-600 text-gray-900 dark:text-white rounded-xl font-semibold shadow-lg transition-all flex items-center justify-center gap-2 mx-auto"
                    >
                        Load More Articles <ArrowRight size={16} />
                    </button>
                </div>
            )}
        </div>
      );
  };

  const renderFeaturesPage = () => (
      <div className="max-w-5xl mx-auto py-8 animate-in fade-in duration-500">
          <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">Powerful Features Built for Scale</h2>
              <p className="text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
                  Discover why professionals choose PayMint QR for their campaigns. We combine aesthetics with robust functionality.
              </p>
          </div>

          <div className="grid md:grid-cols-2 gap-x-12 gap-y-16">
              {[
                  { title: "Custom Brand Integration", desc: "Stop settling for boring black and white squares. Upload your own logo, select your exact brand hex colors, and choose from various frame styles to make your QR code an extension of your visual identity. Our editor allows pixel-perfect customization.", icon: FileText },
                  { title: "Production-Ready Vector Export", desc: "For print materials like billboards, packaging, and magazines, quality is non-negotiable. Export your QR codes in SVG format to ensure they remain crisp and scannable at any size, from business cards to building wraps.", icon: ScanLine },
                  { title: "Advanced Error Correction", desc: "Our QR codes are built with high redundancy levels (Level H). This means your code remains scannable even if up to 30% of it is damaged or covered by a logo. Perfect for real-world durability.", icon: CheckCircle2 },
                  { title: "Static Privacy Guarantee", desc: "When you create a static QR code with PayMint, the data is encoded directly into the image. We do not store your data, track your users, or inject redirects. Your data belongs entirely to you.", icon: Shield },
                  { title: "Universal Compatibility", desc: "We adhere strictly to ISO/IEC 18004 standards. This ensures your QR codes are readable by 100% of smartphone cameras (iOS & Android) and dedicated barcode scanners without requiring special apps.", icon: ScanLine },
                  { title: "Multi-Modal Content Support", desc: "One platform for all your needs. Generate UPI payment codes for India, vCards for networking, WiFi login credentials for hospitality, app store deep links, and rich text for information sharing.", icon: BookOpen },
              ].map((f, i) => (
                  <div key={i} className="flex gap-5">
                      <div className="flex-shrink-0 w-14 h-14 bg-paymint-50 dark:bg-paymint-900/20 text-paymint-500 rounded-2xl flex items-center justify-center">
                          <f.icon size={28} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{f.title}</h3>
                        <p className="text-gray-500 dark:text-gray-400 leading-relaxed">{f.desc}</p>
                      </div>
                  </div>
              ))}
          </div>
      </div>
  );

  const renderAboutPage = () => (
      <div className="max-w-4xl mx-auto py-12 animate-in fade-in duration-500">
          <div className="bg-white dark:bg-dark-800 rounded-3xl p-8 md:p-16 shadow-xl border border-gray-100 dark:border-dark-700">
              <div className="w-16 h-16 bg-paymint-50 dark:bg-paymint-900/20 text-paymint-500 rounded-2xl flex items-center justify-center mb-8">
                  <Info size={32} />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-8">About PayMint QR</h1>
              
              <div className="space-y-8 text-gray-600 dark:text-gray-300 leading-relaxed text-lg">
                  <p>
                      Welcome to PayMint QR, the premier destination for creating high-quality, customized, and reliable QR codes. Founded with a vision to bridge the gap between the physical and digital worlds, we have grown into a trusted tool for millions of users, ranging from individual freelancers to Fortune 500 companies.
                  </p>
                  <p>
                      In the early days of QR technology, options were limited. Generators were either expensive, riddled with ads, or produced ugly, unbranded codes that designers hated to use. We believed that functional technology didn't have to be ugly. We set out to build a platform that put design and user experience first.
                  </p>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white pt-4">Our Mission</h3>
                  <p>
                      Our mission is simple: <strong>To empower seamless digital connections through accessible technology.</strong> We believe that sharing a payment link, a website URL, or contact information should be as easy as a single scan. We are committed to providing tools that are not only powerful but also respectful of user privacy and data security.
                  </p>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white pt-4">Why Choose Us?</h3>
                  <p>
                      Unlike many other services that force you into subscriptions for basic features, PayMint provides robust static QR generation completely for free. We are transparent about our business model: we offer premium features for power users who need dynamic editing and analytics, but we never hold your basic data hostage.
                  </p>
                  <p>
                      Our team consists of passionate developers, designers, and product strategists working remotely from around the globe. We are constantly updating our algorithms to ensure the highest scan rates and compatibility with the latest mobile operating systems.
                  </p>
                  <div className="pt-8 border-t border-gray-200 dark:border-dark-600 mt-8">
                      <p className="text-sm font-medium text-gray-500">
                          PayMint QR is a product of Elvora Labs. <br/>
                          Established 2023. Helping the world scan better.
                      </p>
                  </div>
              </div>
          </div>
      </div>
  );

  const renderPrivacyPage = () => (
      <div className="max-w-4xl mx-auto py-12 animate-in fade-in duration-500">
           <div className="bg-white dark:bg-dark-800 rounded-3xl p-8 md:p-16 shadow-xl border border-gray-100 dark:border-dark-700">
              <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 text-blue-500 rounded-2xl flex items-center justify-center mb-8">
                  <Shield size={32} />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-8">Privacy Policy</h1>
              
              <div className="space-y-8 text-gray-600 dark:text-gray-300 leading-relaxed">
                  <p className="text-sm text-gray-500">Last Updated: February 24, 2025</p>
                  
                  <p>At PayMint QR, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website. Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site.</p>

                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">1. Information We Collect</h3>
                      <p className="mb-4"><strong>Personal Data:</strong> We may collect personally identifiable information, such as your name and email address, only when you voluntarily submit it to us (e.g., signing up for an account or contacting support).</p>
                      <p><strong>QR Code Data:</strong> For Static QR codes, the data you enter (URLs, phone numbers, etc.) is encoded directly into the QR image on your device. We do not store this data on our servers. For Dynamic QR codes, we store the destination URL to enable redirection and analytics.</p>
                  </section>
                  
                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">2. How We Use Your Information</h3>
                      <p>We use the information we collect to operate and maintain our website, improve user experience, and send you administrative emails. We do not sell, trade, or rent your personal identification information to others.</p>
                  </section>

                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">3. Security of Your Data</h3>
                      <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.</p>
                  </section>
                  
                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">4. Third-Party Websites</h3>
                      <p>The Site may contain links to third-party websites and applications of interest, including advertisements and external services, that are not affiliated with us. Once you have used these links to leave the Site, any information you provide to these third parties is not covered by this Privacy Policy, and we cannot guarantee the safety and privacy of your information.</p>
                  </section>

                   <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">5. Contact Us</h3>
                      <p>If you have questions or comments about this Privacy Policy, please contact us at: <br/><span className="font-bold text-paymint-500">elvoralabs9@gmail.com</span></p>
                  </section>
              </div>
          </div>
      </div>
  );

  const renderTermsPage = () => (
      <div className="max-w-4xl mx-auto py-12 animate-in fade-in duration-500">
           <div className="bg-white dark:bg-dark-800 rounded-3xl p-8 md:p-16 shadow-xl border border-gray-100 dark:border-dark-700">
              <div className="w-16 h-16 bg-purple-50 dark:bg-purple-900/20 text-purple-500 rounded-2xl flex items-center justify-center mb-8">
                  <Shield size={32} />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-8">Terms of Service</h1>
              
              <div className="space-y-8 text-gray-600 dark:text-gray-300 leading-relaxed">
                  <p className="text-sm text-gray-500">Last Updated: February 24, 2025</p>
                  
                  <p>These Terms of Service ("Terms") govern your access to and use of the PayMint QR website and services. By accessing or using the Service, you agree to be bound by these Terms.</p>

                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">1. Use of Service</h3>
                      <p className="mb-4">PayMint QR grants you a limited, non-exclusive, non-transferable, and revocable license to use the Service for its intended purposes. You agree not to use the Service for any illegal purpose or in violation of any local, state, national, or international law.</p>
                      <p>You are responsible for ensuring that any content you encode into a QR code does not violate the rights of others, including copyright, trademark, privacy, publicity, or other personal or proprietary rights.</p>
                  </section>
                  
                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">2. Intellectual Property</h3>
                      <p>The Service and its original content, features, and functionality are and will remain the exclusive property of PayMint QR and its licensors. The Service is protected by copyright, trademark, and other laws. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of PayMint QR.</p>
                  </section>

                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">3. Disclaimer of Warranties</h3>
                      <p>The Service is provided on an "AS IS" and "AS AVAILABLE" basis. PayMint QR makes no representations or warranties of any kind, express or implied, regarding the operation of the Service or the information, content, materials, or products included on the Service. You expressly agree that your use of the Service is at your sole risk.</p>
                  </section>
                  
                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">4. Limitation of Liability</h3>
                      <p>In no event shall PayMint QR, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.</p>
                  </section>

                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">5. Changes to Terms</h3>
                      <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>
                  </section>
                  
                  <section>
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">6. Contact Us</h3>
                      <p>If you have any questions about these Terms, please contact us at: <br/><span className="font-bold text-paymint-500">elvoralabs9@gmail.com</span></p>
                  </section>
              </div>
          </div>
      </div>
  );

  switch(page) {
      case 'scan': return renderScanPage();
      case 'blog': return renderBlogPage();
      case 'features': return renderFeaturesPage();
      case 'about': return renderAboutPage();
      case 'privacy': return renderPrivacyPage();
      case 'terms': return renderTermsPage();
      default: return null;
  }
};

export default Pages;
