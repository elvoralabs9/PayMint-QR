
import React, { useRef } from 'react';
import { 
  Wallet, Link2, Users, Smartphone, Type, Wifi, 
  MessageCircle, Instagram, Facebook, ChevronRight, ChevronLeft
} from 'lucide-react';
import { QRMode } from '../types';

interface TypeSliderProps {
  activeMode: QRMode;
  setMode: (mode: QRMode) => void;
}

const TypeSlider: React.FC<TypeSliderProps> = ({ activeMode, setMode }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const items: { id: QRMode; label: string; icon: any; color: string }[] = [
    { id: 'payment', label: 'Payment', icon: Wallet, color: 'text-emerald-500' },
    { id: 'url', label: 'Website', icon: Link2, color: 'text-blue-500' },
    { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle, color: 'text-green-500' },
    { id: 'instagram', label: 'Instagram', icon: Instagram, color: 'text-pink-500' },
    { id: 'facebook', label: 'Facebook', icon: Facebook, color: 'text-blue-600' },
    { id: 'contact', label: 'Contact', icon: Users, color: 'text-orange-500' },
    { id: 'wifi', label: 'Wi-Fi', icon: Wifi, color: 'text-cyan-500' },
    { id: 'app', label: 'App Store', icon: Smartphone, color: 'text-purple-500' },
    { id: 'text', label: 'Text', icon: Type, color: 'text-gray-500' },
  ];

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200;
      scrollRef.current.scrollBy({
        left: direction === 'right' ? scrollAmount : -scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="relative group mb-6">
      {/* Left Gradient/Button */}
      <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-gray-50 dark:from-[#121212] to-transparent z-10 pointer-events-none flex items-center">
        <button 
            onClick={() => scroll('left')}
            className="pointer-events-auto p-1 rounded-full bg-white dark:bg-dark-800 shadow-md text-gray-500 hover:text-paymint-500 hidden md:block transform -translate-x-2 opacity-0 group-hover:opacity-100 transition-all"
        >
            <ChevronLeft size={16} />
        </button>
      </div>

      {/* Scroll Container */}
      <div 
        ref={scrollRef}
        className="flex items-center gap-3 overflow-x-auto pb-4 pt-1 px-1 scrollbar-hide snap-x"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setMode(item.id)}
            title={item.label}
            className={`
              flex items-center gap-2 px-5 py-3 rounded-xl whitespace-nowrap transition-all duration-200 snap-start border
              ${activeMode === item.id 
                ? 'bg-white dark:bg-dark-800 border-paymint-500 shadow-lg shadow-paymint-500/10 scale-105' 
                : 'bg-white dark:bg-dark-800 border-transparent hover:border-gray-200 dark:hover:border-dark-600 text-gray-500 hover:bg-gray-50 dark:hover:bg-dark-700'
              }
            `}
          >
            <item.icon 
                size={18} 
                className={`${activeMode === item.id ? item.color : 'text-gray-400'}`} 
            />
            <span className={`text-sm font-medium ${activeMode === item.id ? 'text-gray-900 dark:text-white' : 'text-gray-500'}`}>
              {item.label}
            </span>
          </button>
        ))}
      </div>

      {/* Right Gradient/Button */}
      <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-gray-50 dark:from-[#121212] to-transparent z-10 pointer-events-none flex items-center justify-end">
         <button 
            onClick={() => scroll('right')}
            className="pointer-events-auto p-1 rounded-full bg-white dark:bg-dark-800 shadow-md text-gray-500 hover:text-paymint-500 hidden md:block transform translate-x-2 opacity-0 group-hover:opacity-100 transition-all"
        >
            <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
};

export default TypeSlider;
