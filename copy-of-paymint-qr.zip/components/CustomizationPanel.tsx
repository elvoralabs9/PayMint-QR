
import React from 'react';
import { Upload, Palette, LayoutGrid, Maximize, Square, Circle, Trash2 } from 'lucide-react';
import { QRCodeConfig } from '../types';

interface CustomizationPanelProps {
  config: Omit<QRCodeConfig, 'value'>;
  updateConfig: (key: keyof Omit<QRCodeConfig, 'value'>, value: any) => void;
  onLogoUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  clearLogo: () => void;
}

const CustomizationPanel: React.FC<CustomizationPanelProps> = ({
  config,
  updateConfig,
  onLogoUpload,
  clearLogo
}) => {
  const predefinedColors = [
    '#000000', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#ef4444', '#0f172a'
  ];

  return (
    <div className="bg-white dark:bg-dark-800 rounded-2xl p-6 shadow-xl border border-gray-200 dark:border-dark-700 space-y-8">
       <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 flex items-center gap-2">
        <span className="w-1 h-6 bg-purple-500 rounded-full"></span>
        Customize Look
      </h2>

      {/* Colors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-600 dark:text-gray-300 mb-3">
            <Palette size={16} /> QR Color
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
            {predefinedColors.map((c) => (
                <button
                key={c}
                onClick={() => updateConfig('fgColor', c)}
                className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${config.fgColor === c ? 'border-paymint-500 ring-2 ring-paymint-500/20' : 'border-transparent hover:border-gray-300 dark:hover:border-dark-600'}`}
                style={{ backgroundColor: c }}
                title={c}
                />
            ))}
            <div className="relative w-8 h-8 rounded-full overflow-hidden border-2 border-gray-300 dark:border-dark-600 hover:border-paymint-500 transition-colors">
                <input 
                type="color" 
                value={config.fgColor}
                onChange={(e) => updateConfig('fgColor', e.target.value)}
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] cursor-pointer p-0 border-0"
                />
            </div>
            </div>
        </div>
        
        {/* Background Color */}
        <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-600 dark:text-gray-300 mb-3">
            <LayoutGrid size={16} /> Background
            </label>
            <div className="flex items-center gap-3">
            <button 
                onClick={() => updateConfig('bgColor', '#ffffff')} 
                className={`h-8 px-3 rounded-lg border text-xs font-medium transition-all ${config.bgColor === '#ffffff' ? 'bg-gray-100 dark:bg-dark-700 border-paymint-500 text-paymint-600 dark:text-paymint-400' : 'border-gray-300 dark:border-dark-600 text-gray-500 hover:border-paymint-400'}`}
            >
                White
            </button>
            <button 
                onClick={() => updateConfig('bgColor', 'transparent')} 
                className={`h-8 px-3 rounded-lg border text-xs font-medium transition-all ${config.bgColor === 'transparent' ? 'bg-gray-100 dark:bg-dark-700 border-paymint-500 text-paymint-600 dark:text-paymint-400' : 'border-gray-300 dark:border-dark-600 text-gray-500 hover:border-paymint-400'}`}
            >
                Transparent
            </button>
            <div className="relative w-8 h-8 rounded-lg border border-gray-300 dark:border-dark-600 overflow-hidden ml-auto">
                <input 
                type="color" 
                value={config.bgColor === 'transparent' ? '#ffffff' : config.bgColor}
                onChange={(e) => updateConfig('bgColor', e.target.value)}
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] cursor-pointer p-0 border-0"
                />
            </div>
            </div>
        </div>
      </div>

      <div className="h-px bg-gray-200 dark:bg-dark-700"></div>

      {/* Shape & Borders */}
      <div className="space-y-6">
        {/* Corner Style */}
        <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-600 dark:text-gray-300 mb-3">
              <Square size={16} /> Corner Style
            </label>
            <div className="flex gap-3">
                {[
                    { id: 'square', label: 'Square', icon: Square },
                    { id: 'rounded', label: 'Rounded', icon: Circle }, // Using circle icon to represent rounded
                    { id: 'extra-rounded', label: 'Soft', icon: Circle } 
                ].map((style) => (
                    <button
                        key={style.id}
                        onClick={() => updateConfig('cornerStyle', style.id)}
                        className={`flex-1 py-2.5 px-2 flex items-center justify-center gap-2 text-xs font-medium rounded-xl border transition-all ${
                            config.cornerStyle === style.id 
                            ? 'bg-paymint-50 dark:bg-paymint-900/20 border-paymint-500 text-paymint-600 dark:text-paymint-400 ring-1 ring-paymint-500/20' 
                            : 'bg-white dark:bg-dark-900 border-gray-200 dark:border-dark-600 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-dark-800'
                        }`}
                    >
                        {style.id === 'square' && <div className="w-3 h-3 bg-current rounded-none" />}
                        {style.id === 'rounded' && <div className="w-3 h-3 bg-current rounded-sm" />}
                        {style.id === 'extra-rounded' && <div className="w-3 h-3 bg-current rounded-full" />}
                        {style.label}
                    </button>
                ))}
            </div>
        </div>

        {/* Border Settings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
                 <label className="flex items-center justify-between text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">
                    <span>Border Width</span>
                    <span className="text-xs text-gray-400">{config.borderConfig.width}px</span>
                </label>
                <input 
                    type="range" 
                    min="0" 
                    max="20" 
                    value={config.borderConfig.width}
                    onChange={(e) => updateConfig('borderConfig', { ...config.borderConfig, width: parseInt(e.target.value) })}
                    className="w-full h-2 bg-gray-200 dark:bg-dark-700 rounded-lg appearance-none cursor-pointer accent-paymint-500"
                />
            </div>
            <div>
                 <label className="flex items-center gap-2 text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">
                    Border Style
                </label>
                <select 
                    value={config.borderConfig.style}
                    onChange={(e) => updateConfig('borderConfig', { ...config.borderConfig, style: e.target.value })}
                    className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-300 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-paymint-500 focus:border-paymint-500"
                    disabled={config.borderConfig.width === 0}
                >
                    <option value="solid">Solid</option>
                    <option value="dashed">Dashed</option>
                    <option value="dotted">Dotted</option>
                    <option value="double">Double</option>
                </select>
            </div>
        </div>
         
         {/* Border Color */}
         {config.borderConfig.width > 0 && (
             <div className="flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Color:</span>
                <div className="flex gap-2">
                    {['#000000', '#ffffff', '#10b981', '#3b82f6', '#ef4444'].map(c => (
                         <button
                         key={c}
                         onClick={() => updateConfig('borderConfig', { ...config.borderConfig, color: c })}
                         className={`w-6 h-6 rounded-full border ${config.borderConfig.color === c ? 'ring-2 ring-offset-2 ring-gray-400 dark:ring-gray-500 border-transparent' : 'border-gray-300 dark:border-gray-600'}`}
                         style={{ backgroundColor: c }}
                         />
                    ))}
                </div>
             </div>
         )}
      </div>

      <div className="h-px bg-gray-200 dark:bg-dark-700"></div>

      {/* Logo Upload & Size */}
      <div>
        <label className="flex items-center gap-2 text-sm font-medium text-gray-600 dark:text-gray-300 mb-3">
          <Upload size={16} /> Add Logo
        </label>
        
        {!config.logoUrl ? (
          <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-gray-300 dark:border-dark-600 rounded-xl cursor-pointer hover:border-paymint-500 hover:bg-paymint-50 dark:hover:bg-paymint-900/10 transition-all group">
            <div className="flex flex-col items-center justify-center pt-3 pb-4">
              <Upload className="w-6 h-6 mb-2 text-gray-400 group-hover:text-paymint-500 transition-colors" />
              <p className="text-xs text-gray-500 dark:text-gray-400">Upload (PNG/JPG) • Max 2MB</p>
            </div>
            <input type="file" className="hidden" accept="image/*" onChange={onLogoUpload} />
          </label>
        ) : (
          <div className="space-y-4 bg-gray-50 dark:bg-dark-900 p-4 rounded-xl border border-gray-200 dark:border-dark-600">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-white p-1 border border-gray-200 shadow-sm">
                         <img src={config.logoUrl} alt="Logo" className="w-full h-full object-contain" />
                    </div>
                    <div>
                        <p className="text-xs font-medium text-gray-900 dark:text-white">Custom Logo</p>
                        <p className="text-[10px] text-gray-500">Added successfully</p>
                    </div>
                </div>
                <button 
                onClick={clearLogo}
                className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                title="Remove Logo"
                >
                    <Trash2 size={16} />
                </button>
            </div>
            
            {/* Logo Size Slider */}
            <div>
                 <label className="flex items-center justify-between text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
                    <div className="flex items-center gap-1"><Maximize size={12}/> Size Scale</div>
                    <span>{config.logoSize}%</span>
                 </label>
                 <input 
                    type="range" 
                    min="10" 
                    max="40" 
                    step="1"
                    value={config.logoSize}
                    onChange={(e) => updateConfig('logoSize', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 dark:bg-dark-700 rounded-lg appearance-none cursor-pointer accent-paymint-500"
                />
                 <div className="flex justify-between mt-1 text-[10px] text-gray-400">
                     <span>Small</span>
                     <span>Max</span>
                 </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomizationPanel;
