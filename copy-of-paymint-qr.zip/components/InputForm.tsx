
import React, { useState } from 'react';
import { PaymentDetails, ContactDetails, AppDetails, WifiDetails, SocialDetails, QRMode, CURRENCIES } from '../types';
import { AtSign, User, Link as LinkIcon, Smartphone, Mail, Lock, Wifi, AlignLeft, Sparkles, MessageCircle, Instagram, Facebook, Type } from 'lucide-react';

interface InputFormProps {
  mode: QRMode;
  themeColor: string; // Passed from App.tsx
  paymentDetails: PaymentDetails;
  contactDetails: ContactDetails;
  appDetails: AppDetails;
  wifiDetails: WifiDetails;
  socialDetails: SocialDetails;
  urlValue: string;
  textValue: string;
  fontSize: number;
  
  setPaymentDetails: React.Dispatch<React.SetStateAction<PaymentDetails>>;
  setContactDetails: React.Dispatch<React.SetStateAction<ContactDetails>>;
  setAppDetails: React.Dispatch<React.SetStateAction<AppDetails>>;
  setWifiDetails: React.Dispatch<React.SetStateAction<WifiDetails>>;
  setSocialDetails: React.Dispatch<React.SetStateAction<SocialDetails>>;
  setUrlValue: (val: string) => void;
  setTextValue: (val: string) => void;
  setFontSize: (val: number) => void;
  onGenerate: () => void;
}

const InputForm: React.FC<InputFormProps> = ({ 
  mode, 
  themeColor,
  paymentDetails, setPaymentDetails,
  contactDetails, setContactDetails,
  appDetails, setAppDetails,
  wifiDetails, setWifiDetails,
  socialDetails, setSocialDetails,
  urlValue, setUrlValue,
  textValue, setTextValue,
  fontSize, setFontSize,
  onGenerate
}) => {
  
  // Local state for validation
  const [urlError, setUrlError] = useState('');

  // Helper to apply theme color to icons
  const iconStyle = { color: themeColor };

  const renderPaymentForm = () => {
    // Robustly find the symbol for the selected currency
    const selectedCurrencyObj = CURRENCIES.find(c => c.code === paymentDetails.currency);
    const currencySymbol = selectedCurrencyObj ? selectedCurrencyObj.symbol : (CURRENCIES[0].symbol || '$');

    return (
      <div className="space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-500">
        <div className="relative">
          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider">UPI ID / VPA</label>
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <AtSign size={16} style={iconStyle} />
            </div>
            <input
              type="text"
              value={paymentDetails.upiId}
              onChange={(e) => setPaymentDetails({...paymentDetails, upiId: e.target.value})}
              placeholder="merchant@upi"
              className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-2 focus:ring-opacity-50 block pl-10 p-3 transition-all"
              style={{ focusRingColor: themeColor }}
            />
          </div>
        </div>

        <div className="relative">
          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider">Payee Name (Optional)</label>
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <User size={16} style={iconStyle} />
            </div>
            <input
              type="text"
              value={paymentDetails.name}
              onChange={(e) => setPaymentDetails({...paymentDetails, name: e.target.value})}
              placeholder="Business Name"
              className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-2 focus:ring-opacity-50 block pl-10 p-3 transition-all"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 relative">
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider">Amount</label>
              <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none z-10">
                  {/* Dynamic Currency Symbol - z-10 added for visibility over input */}
                  <span className="text-base font-bold opacity-90" style={{ color: themeColor }}>{currencySymbol}</span>
              </div>
              <input
                  type="number"
                  value={paymentDetails.amount}
                  onChange={(e) => setPaymentDetails({...paymentDetails, amount: e.target.value})}
                  placeholder="0.00"
                  className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-2 focus:ring-opacity-50 block pl-10 p-3 transition-all"
              />
              </div>
          </div>
          <div className="relative">
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider">Currency</label>
              <select
                  value={paymentDetails.currency}
                  onChange={(e) => setPaymentDetails({...paymentDetails, currency: e.target.value})}
                  className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-2 focus:ring-opacity-50 block p-3 transition-all appearance-none"
              >
                  {CURRENCIES.map(c => (
                      <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>
                  ))}
              </select>
          </div>
        </div>
      </div>
    );
  };

  const renderUrlForm = () => {
    const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        setUrlValue(val);
        
        // Robust URL validation
        if (val && !/^(https?:\/\/)/i.test(val)) {
            setUrlError('URL must start with http:// or https://');
        } else {
            setUrlError('');
        }
    };

    return (
        <div className="relative animate-in fade-in slide-in-from-bottom-2 duration-500">
        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider">Website URL</label>
        <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <LinkIcon size={16} style={iconStyle} />
            </div>
            <input
            type="url"
            value={urlValue}
            onChange={handleUrlChange}
            placeholder="https://example.com"
            className={`w-full bg-gray-50 dark:bg-dark-900 border text-gray-900 dark:text-white text-sm rounded-lg focus:ring-2 focus:ring-opacity-50 block pl-10 p-3 transition-all ${urlError ? 'border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-dark-600'}`}
            />
        </div>
        {urlError && <p className="text-red-500 text-xs mt-1">{urlError}</p>}
        </div>
    );
  };

  const renderContactForm = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
        <div className="grid grid-cols-2 gap-4">
            <div>
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">First Name</label>
                <input type="text" value={contactDetails.firstName} onChange={e => setContactDetails({...contactDetails, firstName: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-3 focus:ring-2 focus:ring-opacity-50" placeholder="John" />
            </div>
            <div>
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Last Name</label>
                <input type="text" value={contactDetails.lastName} onChange={e => setContactDetails({...contactDetails, lastName: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-3 focus:ring-2 focus:ring-opacity-50" placeholder="Doe" />
            </div>
        </div>
        <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Smartphone size={16} style={iconStyle}/></div>
            <input type="tel" value={contactDetails.phone} onChange={e => setContactDetails({...contactDetails, phone: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg pl-10 p-3 focus:ring-2 focus:ring-opacity-50" placeholder="Phone Number" />
        </div>
        <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><Mail size={16} style={iconStyle}/></div>
            <input type="email" value={contactDetails.email} onChange={e => setContactDetails({...contactDetails, email: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg pl-10 p-3 focus:ring-2 focus:ring-opacity-50" placeholder="Email Address" />
        </div>
    </div>
  );

  const renderSocialForm = (type: 'whatsapp' | 'instagram' | 'facebook') => (
      <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
          {type === 'whatsapp' ? (
              <>
                <div className="relative group">
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Phone Number (with Country Code)</label>
                    <div className="absolute inset-y-0 left-0 top-6 pl-3 flex items-center pointer-events-none"><MessageCircle size={16} style={iconStyle}/></div>
                    <input type="tel" value={socialDetails.phone} onChange={e => setSocialDetails({...socialDetails, phone: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg pl-10 p-3 focus:ring-2 focus:ring-opacity-50" placeholder="+91 9876543210" />
                </div>
                <div className="relative group">
                    <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Pre-filled Message (Optional)</label>
                    <textarea rows={3} value={socialDetails.message} onChange={e => setSocialDetails({...socialDetails, message: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-3 focus:ring-2 focus:ring-opacity-50" placeholder="Hi, I would like to know more..." />
                </div>
              </>
          ) : (
              <div className="relative group">
                <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Username / Profile Link</label>
                <div className="absolute inset-y-0 left-0 top-6 pl-3 flex items-center pointer-events-none">
                    {type === 'instagram' ? <Instagram size={16} style={iconStyle}/> : <Facebook size={16} style={iconStyle}/>}
                </div>
                <input type="text" value={socialDetails.username} onChange={e => setSocialDetails({...socialDetails, username: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg pl-10 p-3 focus:ring-2 focus:ring-opacity-50" placeholder={type === 'instagram' ? "@username" : "username"} />
            </div>
          )}
      </div>
  );

  const renderAppForm = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
       <div className="relative group">
          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Google Play URL</label>
          <input type="url" value={appDetails.androidUrl} onChange={e => setAppDetails({...appDetails, androidUrl: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-3 focus:ring-2 focus:ring-opacity-50" placeholder="https://play.google.com/store/..." />
       </div>
       <div className="relative group">
          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">App Store URL</label>
          <input type="url" value={appDetails.iosUrl} onChange={e => setAppDetails({...appDetails, iosUrl: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-3 focus:ring-2 focus:ring-opacity-50" placeholder="https://apps.apple.com/..." />
       </div>
    </div>
  );

  const renderTextForm = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
        <div className="relative group">
            <div className="absolute top-9 left-3 pointer-events-none"><AlignLeft size={16} style={iconStyle}/></div>
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider">Plain Text</label>
            <textarea
                rows={4}
                value={textValue}
                onChange={(e) => setTextValue(e.target.value)}
                placeholder="Enter your text here..."
                className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-2 focus:ring-opacity-50 block pl-10 p-3 transition-all resize-none"
            />
        </div>
        {/* Font Size Slider */}
        <div>
             <label className="flex items-center justify-between text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
                <div className="flex items-center gap-1"><Type size={12}/> Font Size</div>
                <span>{fontSize}px</span>
             </label>
             <input 
                type="range" 
                min="8" 
                max="72" 
                step="1"
                value={fontSize}
                onChange={(e) => setFontSize(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 dark:bg-dark-700 rounded-lg appearance-none cursor-pointer accent-paymint-500"
            />
             <div className="flex justify-between mt-1 text-[10px] text-gray-400">
                 <span>8px</span>
                 <span>72px</span>
             </div>
        </div>
    </div>
  );

  const renderWifiForm = () => (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
         <div className="relative group">
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Network Name (SSID)</label>
            <div className="absolute inset-y-0 left-0 top-6 pl-3 flex items-center pointer-events-none"><Wifi size={16} style={iconStyle}/></div>
            <input type="text" value={wifiDetails.ssid} onChange={e => setWifiDetails({...wifiDetails, ssid: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg pl-10 p-3 focus:ring-2 focus:ring-opacity-50" placeholder="WiFi Name" />
         </div>
         <div className="relative group">
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Password</label>
            <div className="absolute inset-y-0 left-0 top-6 pl-3 flex items-center pointer-events-none"><Lock size={16} style={iconStyle}/></div>
            <input type="text" value={wifiDetails.password} onChange={e => setWifiDetails({...wifiDetails, password: e.target.value})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg pl-10 p-3 focus:ring-2 focus:ring-opacity-50" placeholder="WiFi Password" />
         </div>
         <div>
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">Encryption</label>
            <select value={wifiDetails.encryption} onChange={e => setWifiDetails({...wifiDetails, encryption: e.target.value as any})} className="w-full bg-gray-50 dark:bg-dark-900 border border-gray-200 dark:border-dark-600 text-gray-900 dark:text-white text-sm rounded-lg p-3 focus:ring-2 focus:ring-opacity-50">
                <option value="WPA">WPA/WPA2</option>
                <option value="WEP">WEP</option>
                <option value="nopass">No Encryption</option>
            </select>
         </div>
    </div>
  );

  return (
    <div 
        className="bg-white dark:bg-dark-800 rounded-2xl p-6 shadow-xl border transition-all duration-300"
        style={{ borderColor: themeColor ? `${themeColor}40` : '', boxShadow: `0 10px 30px -10px ${themeColor}20` }}
    >
      <h2 
        className="text-lg font-semibold mb-6 flex items-center gap-2 transition-colors duration-300"
        style={{ color: themeColor || 'inherit' }}
      >
        <span className="w-1 h-6 rounded-full" style={{ backgroundColor: themeColor }}></span>
        {mode === 'payment' && 'Payment Details'}
        {mode === 'url' && 'Website URL'}
        {mode === 'contact' && 'Contact Information'}
        {mode === 'app' && 'App Store Links'}
        {mode === 'text' && 'Text Content'}
        {mode === 'wifi' && 'Wi-Fi Network'}
        {mode === 'whatsapp' && 'WhatsApp Configuration'}
        {mode === 'instagram' && 'Instagram Profile'}
        {mode === 'facebook' && 'Facebook Profile'}
      </h2>
      
      <div className="mb-8">
        {mode === 'payment' && renderPaymentForm()}
        {mode === 'url' && renderUrlForm()}
        {mode === 'contact' && renderContactForm()}
        {mode === 'app' && renderAppForm()}
        {mode === 'text' && renderTextForm()}
        {mode === 'wifi' && renderWifiForm()}
        {(mode === 'whatsapp' || mode === 'instagram' || mode === 'facebook') && renderSocialForm(mode)}
      </div>

      <button
        onClick={onGenerate}
        disabled={!!urlError && mode === 'url'}
        style={{ backgroundColor: themeColor }}
        className="w-full text-white font-bold py-4 px-6 rounded-xl shadow-lg transform transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 text-lg group hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
      >
        <Sparkles size={20} className="animate-pulse group-hover:rotate-12 transition-transform" />
        Generate QR Code
      </button>
    </div>
  );
};

export default InputForm;
