
import React, { useRef, useState } from 'react';
import QRCode from 'react-qr-code';
import { Download, Share2, Check, Printer } from 'lucide-react';
import { QRCodeConfig } from '../types';

interface QRPreviewProps {
  value: string;
  config: Omit<QRCodeConfig, 'value'>;
  isUpdating: boolean;
  activeMode: string;
}

const QRPreview: React.FC<QRPreviewProps> = ({ value, config, isUpdating, activeMode }) => {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [sharing, setSharing] = useState(false);

  // Map corner styles
  const getBorderRadius = () => {
      switch(config.cornerStyle) {
          case 'rounded': return '12px';
          case 'extra-rounded': return '24px';
          case 'square': default: return '0px';
      }
  };

  const generateCanvas = async (scale = 1, isPrint = false) => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx || !wrapperRef.current) return null;

      const svg = wrapperRef.current.querySelector('svg');
      if(!svg) return null;

      // Base size for the QR code part
      const baseSize = 1024; 
      // Print margin/bleed settings
      const padding = isPrint ? 200 : 50; // Extra space for crop marks if print
      const totalSize = baseSize + (padding * 2);
      
      canvas.width = totalSize;
      canvas.height = totalSize;

      // Fill Background
      ctx.fillStyle = config.bgColor === 'transparent' ? '#ffffff' : config.bgColor;
      if (isPrint) ctx.fillStyle = "#ffffff"; // Always white bg paper for print logic usually
      ctx.fillRect(0, 0, totalSize, totalSize);

      // Serialize SVG
      const svgData = new XMLSerializer().serializeToString(svg);
      const img = new Image();
      
      await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = reject;
          img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgData)));
      });

      // Draw Border logic
      const borderWidth = config.borderConfig.width * (baseSize / 256); // Scale width relative to preview size
      const drawX = padding;
      const drawY = padding;
      const drawSize = baseSize;

      // Draw QR
      ctx.drawImage(img, drawX, drawY, drawSize, drawSize);

      // Draw Border manually on canvas if needed (since HTML border isn't part of SVG)
      if (config.borderConfig.width > 0 && config.borderConfig.style !== 'none') {
        ctx.lineWidth = borderWidth;
        ctx.strokeStyle = config.borderConfig.color;
        
        // Dashed/Dotted logic
        if (config.borderConfig.style === 'dashed') ctx.setLineDash([borderWidth * 3, borderWidth * 2]);
        else if (config.borderConfig.style === 'dotted') ctx.setLineDash([borderWidth, borderWidth]);
        else if (config.borderConfig.style === 'double') {
             // Simple double border simulation: draw another rect outside? 
             // For simplicity in canvas, let's just stick to single line or simple dash
        } else {
            ctx.setLineDash([]);
        }
        
        // Rounded Rect Path
        const r = config.cornerStyle === 'square' ? 0 : (config.cornerStyle === 'rounded' ? 40 : 90);
        // Adjust rect to sit outside the QR slightly
        const borderOffset = borderWidth / 2 + 10; 
        
        ctx.beginPath();
        ctx.roundRect(drawX - borderOffset, drawY - borderOffset, drawSize + (borderOffset*2), drawSize + (borderOffset*2), r);
        ctx.stroke();
        ctx.setLineDash([]); // Reset
      }

      // Draw Logo (Overlay)
      if (config.logoUrl) {
          const logoImg = new Image();
          logoImg.crossOrigin = "anonymous";
          await new Promise((resolve) => {
              logoImg.onload = resolve;
              logoImg.onerror = resolve; // Fail gracefully
              logoImg.src = config.logoUrl!;
          });
          
          const logoSizePx = (drawSize * config.logoSize) / 100;
          const logoX = drawX + (drawSize - logoSizePx) / 2;
          const logoY = drawY + (drawSize - logoSizePx) / 2;
          
          // Logo Background (White, rounded, larger than logo)
          // Add extra padding factor relative to scale
          const logoPadding = 20; 
          const logoBgSize = logoSizePx + (logoPadding * 2);
          const logoBgX = logoX - logoPadding;
          const logoBgY = logoY - logoPadding;
          const logoCornerRadius = 40; // Rounded corners for logo box

          ctx.save();
          
          // Shadow
          ctx.shadowColor = "rgba(0,0,0,0.3)";
          ctx.shadowBlur = 20;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 4;

          ctx.fillStyle = "#ffffff";
          ctx.beginPath();
          ctx.roundRect(logoBgX, logoBgY, logoBgSize, logoBgSize, logoCornerRadius);
          ctx.fill();
          
          // Restore shadow
          ctx.restore();

          // Border for Logo Box
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 4;
          ctx.stroke();

          // Draw the actual logo image
          // Clip to ensure it stays inside if square, or just draw it centered
          ctx.drawImage(logoImg, logoX, logoY, logoSizePx, logoSizePx);
      }

      // Draw Crop Marks for Print Mode
      if (isPrint) {
          ctx.strokeStyle = "#000000";
          ctx.lineWidth = 4;
          const bleedLen = 60;
          const margin = 40; // Distance from edge of canvas
          
          // Top Left
          ctx.beginPath();
          ctx.moveTo(margin, margin + bleedLen);
          ctx.lineTo(margin, margin);
          ctx.lineTo(margin + bleedLen, margin);
          ctx.stroke();

          // Top Right
          ctx.beginPath();
          ctx.moveTo(totalSize - margin - bleedLen, margin);
          ctx.lineTo(totalSize - margin, margin);
          ctx.lineTo(totalSize - margin, margin + bleedLen);
          ctx.stroke();
          
          // Bottom Left
          ctx.beginPath();
          ctx.moveTo(margin, totalSize - margin - bleedLen);
          ctx.lineTo(margin, totalSize - margin);
          ctx.lineTo(margin + bleedLen, totalSize - margin);
          ctx.stroke();

          // Bottom Right
          ctx.beginPath();
          ctx.moveTo(totalSize - margin - bleedLen, totalSize - margin);
          ctx.lineTo(totalSize - margin, totalSize - margin);
          ctx.lineTo(totalSize - margin, totalSize - margin - bleedLen);
          ctx.stroke();
          
          // Add Text Label
          ctx.font = "30px Arial";
          ctx.fillStyle = "#666";
          ctx.textAlign = "center";
          ctx.fillText("PAYMINT QR - PRINT PROOF", totalSize/2, totalSize - 60);
      }

      return canvas;
  };

  const generateFilename = (ext: string) => {
      // Create descriptive filename: PayMint_Payment_QR_1678886400.png
      const timestamp = Math.floor(Date.now() / 1000);
      const modeCapitalized = activeMode.charAt(0).toUpperCase() + activeMode.slice(1);
      return `PayMint_${modeCapitalized}_QR_${timestamp}.${ext}`;
  };

  const handlePrintExport = async () => {
      setDownloading(true);
      try {
        const canvas = await generateCanvas(1, true);
        if(canvas) {
            const url = canvas.toDataURL("image/png");
            triggerDownload(url, generateFilename('png'));
        }
      } catch (e) {
          console.error(e);
      }
      setDownloading(false);
  };

  const handleDownload = async (format: 'png' | 'svg') => {
      setDownloading(true);
      const filename = generateFilename(format);
      
      if (format === 'svg') {
        const svg = wrapperRef.current?.querySelector('svg');
        if (svg) {
            const svgData = new XMLSerializer().serializeToString(svg);
            const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
            const url = URL.createObjectURL(blob);
            triggerDownload(url, filename);
        }
      } else {
        const canvas = await generateCanvas(1, false);
        if(canvas) {
            triggerDownload(canvas.toDataURL("image/png"), filename);
        }
      }
      setDownloading(false);
  };

  const handleShare = async () => {
    setSharing(true);
    try {
        if (navigator.share) {
            const canvas = await generateCanvas(1, false);
            if (canvas) {
                canvas.toBlob(async (blob) => {
                    if (blob) {
                        const file = new File([blob], generateFilename('png'), { type: "image/png" });
                        await navigator.share({
                            title: 'My PayMint QR Code',
                            text: 'Scan this QR code to pay me!',
                            files: [file]
                        });
                    }
                });
            }
        } else {
            // Fallback
            alert("Sharing is not supported on this browser/device. Please download the image instead.");
        }
    } catch (error) {
        console.error('Error sharing:', error);
    }
    setSharing(false);
  };

  const triggerDownload = (url: string, filename: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Determine Glow Color
  const glowColor = config.fgColor;

  return (
    <div className="flex flex-col h-full">
      {/* Preview Card */}
      <div className="bg-white dark:bg-dark-800 rounded-2xl p-8 flex flex-col items-center justify-center shadow-2xl border border-gray-200 dark:border-dark-700 relative overflow-hidden min-h-[400px] transition-colors duration-300">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-paymint-400 to-blue-500"></div>
        
        {/* Neon Glow Container for the QR itself */}
        <div className={`relative transition-all duration-500 ease-out ${isUpdating ? 'scale-105' : ''}`}>
            {/* Pulse Effect Layer */}
            <div 
                className={`absolute inset-0 rounded-3xl blur-xl transition-opacity duration-500 ${isUpdating ? 'opacity-60' : 'opacity-0'}`}
                style={{ backgroundColor: glowColor }}
            ></div>

            <div 
                ref={wrapperRef}
                className="bg-white p-6 relative z-10 transition-all duration-300" 
                style={{
                    borderRadius: getBorderRadius(),
                    borderWidth: `${config.borderConfig.width}px`,
                    borderColor: config.borderConfig.color,
                    borderStyle: config.borderConfig.style
                }}
            >
                <div className="relative" style={{ height: "auto", maxWidth: 256, width: "100%" }}>
                    <QRCode
                        size={256}
                        style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                        value={value || 'https://paymint-qr.web.app'}
                        viewBox={`0 0 256 256`}
                        fgColor={config.fgColor}
                        bgColor={config.bgColor}
                        level="H"
                    />
                    
                    {/* Logo Overlay */}
                    {config.logoUrl && (
                        <div 
                            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
                             style={{ 
                                width: `${config.logoSize}%`, 
                                height: `${config.logoSize}%` 
                            }}
                        >
                            {/* Glow behind logo when updating */}
                             <div 
                                className={`absolute inset-0 rounded-xl blur-md transition-opacity duration-500 ${isUpdating ? 'opacity-80' : 'opacity-0'}`}
                                style={{ backgroundColor: glowColor, transform: 'scale(1.2)' }}
                             ></div>

                             {/* Logo Container with White BG, Border, Shadow */}
                             <div 
                                className="relative bg-white rounded-xl p-1.5 shadow-md border border-white z-10 w-full h-full flex items-center justify-center"
                                style={{ boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)' }}
                             >
                                 <img 
                                    src={config.logoUrl} 
                                    alt="Logo" 
                                    className="w-full h-full object-contain rounded-lg" 
                                />
                             </div>
                        </div>
                    )}
                </div>
            </div>
        </div>

        <div className="mt-8 text-center space-y-1">
            <p className="text-gray-900 dark:text-white font-bold tracking-wide text-sm">SCAN TO PAY</p>
            <p className="text-gray-400 dark:text-gray-500 text-xs">Generated by PayMint QR</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
        <button 
          onClick={() => handleDownload('png')}
          disabled={downloading}
          className="flex items-center justify-center gap-2 bg-paymint-500 hover:bg-paymint-600 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-paymint-500/20 transition-transform active:scale-95 disabled:opacity-70"
        >
          {downloading ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div> : <Download size={18} />}
          Save PNG
        </button>
        <button 
          onClick={handleShare}
          className="flex items-center justify-center gap-2 bg-white dark:bg-dark-700 hover:bg-gray-50 dark:hover:bg-dark-600 text-gray-900 dark:text-white font-medium py-3 px-4 rounded-xl border border-gray-200 dark:border-dark-600 transition-colors"
        >
          {sharing ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-500"></div> : <Share2 size={18} />}
          Share
        </button>
        
        {/* Print Ready Button - Full Width */}
        <button 
          onClick={handlePrintExport}
          disabled={downloading}
          className="sm:col-span-2 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/20 transition-all hover:scale-[1.01] disabled:opacity-70"
        >
           <Printer size={18} />
           Print-Ready Export (High Res)
        </button>
      </div>
      
      <div className="mt-4 flex items-center justify-center gap-4 text-gray-500 dark:text-gray-400 text-xs">
        <div className="flex items-center gap-1"><Check size={12} className="text-paymint-500" /> 4000px High-Res</div>
        <div className="flex items-center gap-1"><Check size={12} className="text-paymint-500" /> Vector Support</div>
      </div>
    </div>
  );
};

export default QRPreview;
