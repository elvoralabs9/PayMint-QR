
import React from 'react';

interface AdSpaceProps {
  type: 'banner' | 'sidebar' | 'popup';
  className?: string;
}

const AdSpace: React.FC<AdSpaceProps> = ({ type, className = '' }) => {
  
  if (type === 'popup') {
    return (
      <div className="bg-white dark:bg-dark-800 w-full">
          {/* Placeholder Content */}
          <div className="h-64 w-full bg-gray-50 dark:bg-dark-900 flex flex-col items-center justify-center text-center p-4 border-b border-dashed border-gray-300 dark:border-dark-600">
             <span className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Advertisement</span>
             <div className="w-full h-full border-2 border-dashed border-gray-300 dark:border-dark-600 rounded-lg flex items-center justify-center bg-gray-100 dark:bg-dark-800">
                <span className="text-gray-400 font-mono text-sm">Place Ad Code Here<br/>(300x250)</span>
             </div>
          </div>
          <div className="p-4 text-center">
             <h3 className="text-lg font-bold text-gray-900 dark:text-white">Sponsored Content</h3>
             <p className="text-sm text-gray-500 mt-1">This ad supports the free version of PayMint.</p>
          </div>
      </div>
    );
  }

  // Banner (Leaderboard style)
  if (type === 'banner') {
    return (
      <div className={`w-full max-w-4xl mx-auto my-8 ${className}`}>
         <div className="w-full h-[90px] md:h-[120px] bg-gray-50 dark:bg-dark-900 border-2 border-dashed border-gray-200 dark:border-dark-700 rounded-lg flex flex-col items-center justify-center relative overflow-hidden">
            <span className="absolute top-1 right-2 text-[9px] text-gray-400 uppercase">Ad</span>
            <span className="text-gray-400 font-mono text-sm">Native Banner / Display Ad Area</span>
            <span className="text-xs text-gray-300 mt-1">728x90 Responsive</span>
         </div>
      </div>
    );
  }

  // Sidebar (Rectangle style)
  if (type === 'sidebar') {
    return (
      <div className={`w-full ${className}`}>
         <div className="w-full aspect-[4/3] bg-gray-50 dark:bg-dark-900 border-2 border-dashed border-gray-200 dark:border-dark-700 rounded-lg flex flex-col items-center justify-center relative overflow-hidden">
            <span className="absolute top-1 right-2 text-[9px] text-gray-400 uppercase">Ad</span>
            <span className="text-gray-400 font-mono text-sm text-center px-4">Sidebar Ad<br/>(300x250)</span>
         </div>
      </div>
    );
  }

  return null;
};

export default AdSpace;
