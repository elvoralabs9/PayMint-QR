
import React from 'react';
import { 
  Layers, Settings, Download, BarChart3, Users, Repeat, 
  Headphones, CreditCard, Globe, Package, IdCard, Share2, Zap, ShieldCheck, Smartphone 
} from 'lucide-react';
import AdSpace from './AdSpace';

interface LandingPageProps {
  onNavClick: (page: string) => void;
  onOpenPlans: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onNavClick, onOpenPlans }) => {
  
  const useCaseImages = [
    { 
        icon: Package, 
        title: "Packaging", 
        desc: "Product boxes, labels, and inserts.", 
        img: "https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&fit=crop&w=600&q=80" 
    },
    { 
        icon: Share2, 
        title: "Posters", 
        desc: "Drive sign-ups and event registrations.", 
        img: "https://images.unsplash.com/photo-1572021335469-31706a17aaef?auto=format&fit=crop&w=600&q=80" 
    },
    { 
        icon: IdCard, 
        title: "Business Cards", 
        desc: "Share contact details instantly.", 
        img: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&w=600&q=80" 
    },
    { 
        icon: Globe, 
        title: "Storefronts", 
        desc: "Reviews, menus, and hours.", 
        img: "https://images.unsplash.com/photo-1556740738-b6a63e27c4df?auto=format&fit=crop&w=600&q=80" 
    }
  ];

  return (
    <div className="space-y-24 py-16">
      
      {/* How to Create Section */}
      <section className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl md:text-5xl font-bold text-center text-gray-900 dark:text-white mb-16">
          How to create a free <br/> 
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-paymint-400 to-blue-500">
            QR Code in 3 simple steps
          </span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            {
              step: "01",
              title: "Choose your QR Code type",
              desc: "Select from URL, vCard, Plain Text, WiFi, or Social Media based on your specific needs.",
              icon: Layers
            },
            {
              step: "02",
              title: "Customize it your way",
              desc: "Add your brand colors, logo, frames, and distinct patterns to make it truly yours.",
              icon: Settings
            },
            {
              step: "03",
              title: "Download & share",
              desc: "Get your QR in high-resolution PNG, SVG, or Print-Ready formats and share instantly.",
              icon: Download
            }
          ].map((item, idx) => (
            <div key={idx} className="relative group">
               <div className="absolute -inset-0.5 bg-gradient-to-r from-paymint-500 to-blue-500 rounded-2xl opacity-20 group-hover:opacity-100 transition duration-500 blur"></div>
               <div className="relative bg-white dark:bg-dark-800 p-8 rounded-2xl h-full flex flex-col items-start">
                  <div className="w-14 h-14 bg-paymint-50 dark:bg-paymint-900/20 text-paymint-600 dark:text-paymint-400 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <item.icon size={28} />
                  </div>
                  <span className="text-6xl font-bold text-gray-100 dark:text-dark-700 absolute top-4 right-4 -z-0 pointer-events-none">{item.step}</span>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 z-10">{item.title}</h3>
                  <p className="text-gray-500 dark:text-gray-400 leading-relaxed z-10">{item.desc}</p>
               </div>
            </div>
          ))}
        </div>
      </section>

      <AdSpace type="banner" />

      {/* Expanded Content Section */}
      <section className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
         <div>
             <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 text-purple-600 rounded-lg flex items-center justify-center mb-6">
                 <Zap size={24} />
             </div>
             <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Built for Modern Marketing</h2>
             <p className="text-lg text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                 In 2025, QR codes are more than just links—they are the bridge between physical interaction and digital conversion. PayMint QR provides the infrastructure you need to create beautiful, scannable, and trackable codes.
             </p>
             <ul className="space-y-4">
                 {[
                     "99.9% Scannability across all modern devices.",
                     "Vector-quality downloads for large format printing.",
                     "Deep customization to match brand guidelines.",
                     "Privacy-focused static code generation."
                 ].map((point, i) => (
                     <li key={i} className="flex items-center gap-3 text-gray-700 dark:text-gray-300 font-medium">
                         <div className="w-6 h-6 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 flex items-center justify-center">
                             <ShieldCheck size={14} />
                         </div>
                         {point}
                     </li>
                 ))}
             </ul>
         </div>
         <div className="bg-gray-100 dark:bg-dark-800 rounded-3xl p-8 border border-gray-200 dark:border-dark-700 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-paymint-500/20 to-blue-500/20 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
             <div className="grid grid-cols-2 gap-4">
                 <div className="bg-white dark:bg-dark-900 p-4 rounded-xl shadow-sm">
                     <Smartphone className="text-blue-500 mb-2" />
                     <h4 className="font-bold text-gray-900 dark:text-white">Mobile First</h4>
                     <p className="text-xs text-gray-500 mt-1">Optimized for iOS & Android cameras.</p>
                 </div>
                 <div className="bg-white dark:bg-dark-900 p-4 rounded-xl shadow-sm">
                     <Settings className="text-purple-500 mb-2" />
                     <h4 className="font-bold text-gray-900 dark:text-white">Full Control</h4>
                     <p className="text-xs text-gray-500 mt-1">Edit dots, eyes, and frames.</p>
                 </div>
                 <div className="bg-white dark:bg-dark-900 p-4 rounded-xl shadow-sm col-span-2">
                     <div className="flex items-center justify-between mb-2">
                         <h4 className="font-bold text-gray-900 dark:text-white">Scan Analytics</h4>
                         <BarChart3 size={16} className="text-green-500" />
                     </div>
                     <div className="w-full bg-gray-100 dark:bg-dark-700 h-2 rounded-full overflow-hidden">
                         <div className="bg-green-500 w-3/4 h-full rounded-full"></div>
                     </div>
                     <p className="text-xs text-gray-500 mt-2">Track performance in real-time (Pro)</p>
                 </div>
             </div>
         </div>
      </section>

      {/* Why Trust Us Section */}
      <section className="bg-gray-50 dark:bg-dark-900/50 py-20">
         <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
                Why 4 Million+ Users Trust <br/> PayMint for ROI Driven QR Campaigns
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[
                    { icon: BarChart3, title: "Track every scan", desc: "Get real-time insights on scans, unique users, locations and devices." },
                    { icon: Repeat, title: "Free dynamic QR Codes", desc: "Update your content anytime without reprinting the code." },
                    { icon: Users, title: "Collaborate with Your Team", desc: "Invite up to 5 team members to manage QR codes together." },
                    { icon: Headphones, title: "24/7 Customer support", desc: "Our expert team is always ready to fix issues quickly via chat or email." },
                    { icon: CreditCard, title: "Pay for What You Use", desc: "No hidden fees. Enjoy flexible pricing tailored to your needs." },
                    { icon: Globe, title: "Global Standards", desc: "ISO certified QR codes compatible with all modern scanners." }
                ].map((feature, i) => (
                    <div key={i} className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-dark-700 flex flex-col items-center text-center md:items-start md:text-left">
                         <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/20 text-blue-500 rounded-lg flex items-center justify-center mb-4">
                            <feature.icon size={24} />
                         </div>
                         <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{feature.title}</h3>
                         <p className="text-sm text-gray-500 dark:text-gray-400">{feature.desc}</p>
                    </div>
                ))}
            </div>
            
            <div className="mt-12 text-center">
                 <button 
                    className="px-8 py-3 bg-paymint-500 hover:bg-paymint-600 text-white rounded-full font-semibold shadow-lg shadow-paymint-500/30 transition-all cursor-default"
                 >
                    Explore Flex Plans
                 </button>
            </div>
         </div>
      </section>

      {/* Use Cases Grid with Real Images */}
      <section className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
             Where to place your QR Code to improve scans?
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {useCaseImages.map((useCase, i) => (
                  <div key={i} className="group relative overflow-hidden rounded-2xl aspect-[4/5] bg-gray-900 cursor-pointer shadow-xl">
                      {/* Real Image Background */}
                      <div className="absolute inset-0">
                          <img 
                            src={useCase.img} 
                            alt={useCase.title} 
                            className="w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-700"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
                      </div>
                      
                      <div className="absolute inset-0 p-6 flex flex-col justify-end text-white z-10">
                          <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-lg flex items-center justify-center mb-4 border border-white/10">
                              <useCase.icon size={20} />
                          </div>
                          <h3 className="text-xl font-bold mb-2">{useCase.title}</h3>
                          <p className="text-gray-200 text-sm opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                            {useCase.desc}
                          </p>
                      </div>
                  </div>
              ))}
          </div>
      </section>

      {/* Footer */}
      <footer className="bg-white dark:bg-dark-800 border-t border-gray-200 dark:border-dark-700 pt-16 pb-8">
          <div className="max-w-7xl mx-auto px-4">
              {/* Banner Ad placed in Footer as requested */}
              <AdSpace type="banner" className="mb-12" />

              <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                  <div className="col-span-1 md:col-span-2">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Pay<span className="text-paymint-500">Mint</span> QR</h2>
                      <p className="text-gray-500 dark:text-gray-400 max-w-md">
                          The most advanced, customizable, and reliable QR code generator for businesses and individuals. Built for speed and designed for growth.
                      </p>
                  </div>
                  <div>
                      <h4 className="font-bold text-gray-900 dark:text-white mb-4">Product</h4>
                      <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('generate')}>QR Generator</li>
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('features')}>Features</li>
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('blog')}>Blog</li>
                      </ul>
                  </div>
                  <div>
                      <h4 className="font-bold text-gray-900 dark:text-white mb-4">Company</h4>
                      <ul className="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('about')}>About Us</li>
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('contact')}>Contact</li>
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('privacy')}>Privacy Policy</li>
                          <li className="hover:text-paymint-500 cursor-pointer" onClick={() => onNavClick('terms')}>Terms of Service</li>
                      </ul>
                  </div>
              </div>
              
              <div className="border-t border-gray-200 dark:border-dark-700 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
                  <p className="text-sm text-gray-500 dark:text-gray-400">© 2025 PayMint QR. All rights reserved.</p>
              </div>
          </div>
      </footer>
    </div>
  );
};

export default LandingPage;
