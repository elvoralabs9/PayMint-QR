
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import TypeSlider from './components/TypeSlider'; 
import InputForm from './components/InputForm';
import CustomizationPanel from './components/CustomizationPanel';
import QRPreview from './components/QRPreview';
import LandingPage from './components/LandingPage';
import Modals from './components/Modals';
import Pages from './components/Pages'; 
import AdSpace from './components/AdSpace';

import { PaymentDetails, QRCodeConfig, QRMode, ContactDetails, AppDetails, WifiDetails, SocialDetails } from './types';
import { 
    generateUPIString, generateVCard, generateWifiString, generateAppStoreString, 
    generateWhatsappString, generateInstagramString, generateFacebookString 
} from './utils/qrHelpers';
import { auth } from './utils/firebase';
import { onAuthStateChanged, signOut } from "firebase/auth";

const App: React.FC = () => {
  // Theme State
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Global UI State
  const [user, setUser] = useState<any>(null);
  const [activeModal, setActiveModal] = useState<'contact' | 'auth' | 'info' | 'plans' | null>(null);
  const [infoModalTitle, setInfoModalTitle] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Ad States
  const [showAdPopup, setShowAdPopup] = useState(false); // General periodic popup
  const [showInterstitialAd, setShowInterstitialAd] = useState(false); // Feature lock popup
  
  // Page Routing State
  const [currentPage, setCurrentPage] = useState<string>('generate');

  // QR Mode State
  const [activeMode, setActiveMode] = useState<QRMode>('payment');
  const [pendingMode, setPendingMode] = useState<QRMode | null>(null); // Used when user clicks a restricted feature

  // Branding State
  const [themeColor, setThemeColor] = useState<string>('#10b981'); // Default Mint

  // Data States
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails>({ name: '', upiId: '', amount: '', currency: 'INR' });
  const [contactDetails, setContactDetails] = useState<ContactDetails>({ firstName: '', lastName: '', phone: '', email: '', organization: '', title: '' });
  const [appDetails, setAppDetails] = useState<AppDetails>({ iosUrl: '', androidUrl: '' });
  const [wifiDetails, setWifiDetails] = useState<WifiDetails>({ ssid: '', password: '', encryption: 'WPA' });
  const [socialDetails, setSocialDetails] = useState<SocialDetails>({ username: '', phone: '', message: '' });
  
  const [urlValue, setUrlValue] = useState('');
  const [textValue, setTextValue] = useState('');
  const [fontSize, setFontSize] = useState<number>(16); // Font size for text mode

  // Visual Config State
  const [qrConfig, setQrConfig] = useState<Omit<QRCodeConfig, 'value'>>({
    fgColor: '#000000',
    bgColor: '#ffffff',
    logoUrl: null,
    logoSize: 20, 
    cornerStyle: 'rounded',
    borderConfig: {
      width: 0,
      color: '#000000',
      style: 'none'
    }
  });
  
  // Output State
  const [qrValue, setQrValue] = useState('https://paymint.app');
  const [isUpdating, setIsUpdating] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // Theme Toggle Logic
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
        root.classList.add('dark');
    } else {
        root.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Periodic Ad Popup Trigger (Only if NOT showing interstitial)
  useEffect(() => {
      const timer = setTimeout(() => {
          if (!showInterstitialAd) {
             setShowAdPopup(true);
          }
      }, 10000);
      return () => clearTimeout(timer);
  }, [showInterstitialAd]);

  // Branding & QR Logic based on Mode
  useEffect(() => {
      // Update Thematic Color
      let newColor = '#10b981'; // Default Mint
      let newQrColor = qrConfig.fgColor;

      switch (activeMode) {
          case 'facebook':
              newColor = '#1877F2'; // FB Blue
              newQrColor = '#1877F2';
              break;
          case 'whatsapp':
              newColor = '#25D366'; // WA Green
              newQrColor = '#25D366';
              break;
          case 'instagram':
              newColor = '#E1306C'; // Insta Pink
              newQrColor = '#E1306C';
              break;
          case 'url':
              newColor = '#3b82f6'; // Blue
              break;
          case 'payment':
              newColor = '#10b981'; // Mint
              newQrColor = '#000000';
              break;
          default:
              newColor = '#10b981';
      }

      setThemeColor(newColor);
      
      // Update QR Color to match brand if user selects a social mode
      if (['facebook', 'whatsapp', 'instagram'].includes(activeMode)) {
          setQrConfig(prev => ({ ...prev, fgColor: newQrColor }));
      }

      handleGenerate();
  }, [activeMode]);

  // Logic to generate string based on active mode
  const calculateQRValue = () => {
      switch(activeMode) {
          case 'payment': return generateUPIString(paymentDetails);
          case 'url': return urlValue;
          case 'contact': return generateVCard(contactDetails);
          case 'app': return generateAppStoreString(appDetails);
          case 'wifi': return generateWifiString(wifiDetails);
          case 'text': 
              // Incorporate font size into the encoded text (using HTML wrapping as standard method)
              // If default size, return plain text, otherwise wrap it.
              return fontSize !== 16 ? `<div style="font-size:${fontSize}px">${textValue}</div>` : textValue;
          case 'whatsapp': return generateWhatsappString(socialDetails);
          case 'instagram': return generateInstagramString(socialDetails);
          case 'facebook': return generateFacebookString(socialDetails);
          default: return '';
      }
  };

  const handleGenerate = () => {
      setIsUpdating(true);
      const newValue = calculateQRValue();
      setQrValue(newValue || 'https://paymint.app'); 
      setTimeout(() => setIsUpdating(false), 800);
      
      if (window.innerWidth < 1024 && currentPage === 'generate') {
          const previewElement = document.getElementById('qr-preview-section');
          previewElement?.scrollIntoView({ behavior: 'smooth' });
      }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setQrConfig(prev => ({ ...prev, logoUrl: ev.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const updateConfig = (key: keyof typeof qrConfig, value: any) => {
    setQrConfig(prev => ({ ...prev, [key]: value }));
    setIsUpdating(true);
    setTimeout(() => setIsUpdating(false), 400);
  };

  const handleNavClick = (action: string) => {
      if (action === 'contact') {
          setActiveModal('contact');
      } else {
          setCurrentPage(action);
          window.scrollTo({ top: 0, behavior: 'smooth' });
      }
  };

  const handleAuthAction = () => {
      if (user) {
          signOut(auth);
      } else {
          setActiveModal('auth');
      }
  };

  // Interception Logic for Mode Switching
  const handleModeSwitchRequest = (requestedMode: QRMode) => {
      // Free Mode
      if (requestedMode === 'payment') {
          setActiveMode(requestedMode);
          return;
      }

      // Restricted Mode - Check Auth
      if (!user) {
          setActiveModal('auth');
          return;
      }

      // Logged In - Switch immediately (No Ad as per user request)
      setActiveMode(requestedMode);
  };

  const handleInterstitialClose = () => {
      setShowInterstitialAd(false);
      if (pendingMode) {
          setActiveMode(pendingMode);
          setPendingMode(null);
      }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-[#121212] text-gray-900 dark:text-gray-200 transition-colors duration-300 font-sans">
      
      {/* General Periodic Ad Popup */}
      {showAdPopup && !showInterstitialAd && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-300">
              <div className="bg-white dark:bg-dark-800 rounded-lg shadow-2xl w-full max-w-md relative overflow-hidden border border-gray-200 dark:border-dark-700">
                    <AdSpace type="popup" />
                    <button 
                        onClick={() => setShowAdPopup(false)}
                        className="absolute top-2 right-2 p-1 bg-gray-100 dark:bg-dark-700 rounded-full text-gray-500 hover:text-red-500 transition-colors z-50"
                    >
                        <span className="sr-only">Close</span>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
              </div>
          </div>
      )}

      {/* Feature Lock Interstitial Ad - Only shows if trigger is active (currently disabled for logged in users) */}
      {showInterstitialAd && (
          <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
               <div className="bg-white dark:bg-dark-800 rounded-xl shadow-2xl w-full max-w-lg relative overflow-hidden border border-paymint-500">
                    <div className="p-4 bg-paymint-500 text-white text-center font-bold">
                        Ad: Support PayMint to Unlock {pendingMode?.toUpperCase()}
                    </div>
                    <div className="p-6 flex flex-col items-center">
                        <AdSpace type="popup" />
                        <p className="text-sm text-gray-500 mt-4 mb-4 text-center">Please close this ad to proceed to your feature.</p>
                        <button 
                            onClick={handleInterstitialClose}
                            className="w-full py-3 bg-gray-200 dark:bg-dark-700 hover:bg-gray-300 text-gray-800 dark:text-white font-bold rounded-lg flex items-center justify-center gap-2"
                        >
                            <span className="text-red-500 font-bold text-xl">&times;</span> Close Ad & Continue
                        </button>
                    </div>
               </div>
          </div>
      )}

      <Header 
        toggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
        isDarkMode={isDarkMode}
        toggleTheme={() => setIsDarkMode(!isDarkMode)}
        user={user}
        onAuthAction={handleAuthAction}
        onNavClick={handleNavClick}
      />
      
      <main className="flex-1 w-full max-w-[1600px] mx-auto p-4 md:p-8">
          
          {currentPage === 'generate' ? (
            <>
                {/* Main Tool Section */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-20">
                    
                    {/* Left Column: Controls */}
                    <div className="lg:col-span-7 space-y-6">
                    <div className="mb-6">
                        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-3 leading-tight">
                            Create Custom <span style={{ color: themeColor }}>QR Codes</span>
                        </h1>
                        <p className="text-gray-500 dark:text-gray-400 text-lg max-w-xl">
                            Generate branded, high-performance QR codes. Select a mode below to start.
                        </p>
                    </div>

                    {/* Horizontal Type Slider */}
                    <TypeSlider activeMode={activeMode} setMode={handleModeSwitchRequest} />

                    {/* Input Section with Dynamic Theme */}
                    <InputForm 
                        mode={activeMode}
                        themeColor={themeColor}
                        paymentDetails={paymentDetails}
                        setPaymentDetails={setPaymentDetails}
                        contactDetails={contactDetails}
                        setContactDetails={setContactDetails}
                        appDetails={appDetails}
                        setAppDetails={setAppDetails}
                        wifiDetails={wifiDetails}
                        setWifiDetails={setWifiDetails}
                        socialDetails={socialDetails}
                        setSocialDetails={setSocialDetails}
                        urlValue={urlValue}
                        setUrlValue={setUrlValue}
                        textValue={textValue}
                        setTextValue={setTextValue}
                        fontSize={fontSize}
                        setFontSize={setFontSize}
                        onGenerate={handleGenerate}
                    />
                    
                    {/* Customization Section */}
                    <CustomizationPanel 
                        config={qrConfig}
                        updateConfig={updateConfig}
                        onLogoUpload={handleLogoUpload}
                        clearLogo={() => updateConfig('logoUrl', null)}
                    />
                    
                    {/* AdSpace removed from here as requested */}
                    </div>

                    {/* Right Column: Sticky Preview */}
                    <div className="lg:col-span-5" id="qr-preview-section">
                        <div className="sticky top-24">
                            <QRPreview 
                                value={qrValue}
                                config={qrConfig}
                                isUpdating={isUpdating}
                                activeMode={activeMode}
                            />
                        </div>
                    </div>
                </div>

                {/* Landing Page Content */}
                <LandingPage 
                    onNavClick={handleNavClick} 
                    onOpenPlans={() => setActiveModal('plans')}
                />
            </>
          ) : (
            <Pages page={currentPage} onNavigate={handleNavClick} />
          )}
      </main>

      {/* Modals */}
      <Modals 
        isOpen={!!activeModal} 
        type={activeModal} 
        onClose={() => setActiveModal(null)}
        onLogin={() => setActiveModal('auth')} // Just re-open auth if needed
        infoTitle={infoModalTitle}
      />
    </div>
  );
};

export default App;
